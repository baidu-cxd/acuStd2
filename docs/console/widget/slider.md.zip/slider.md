---
title: 滑块选择器（Slider）
author: hwj
sidebarDepth: 0
---

# 滑块选择器（Slider）

通过在连续或间断的区间内滑动锚点来选择合适的数值，区间最小值放在左边，最大值放在右边，并与［数字输入框］搭配使用。通过拖动滑块和［数字输入框］二种方式进行编辑，<mark> 滑块颗粒度及单位视具体场景而定，并进行自动修正；滑条无固定长度，根据页面大小布局可适当调整。<mark> 

![图片](http://baiduyun-guideline.bj.bcebos.com/console/widget/Slider/01.png)

## 示例

适用于数值范围大、数值点较多且精准度要求不高的场景，如带宽、磁盘、cpu等数值选择。其他情况不建议使用。

![图片](http://baiduyun-guideline.bj.bcebos.com/console/widget/Slider/02.png)

## 代码参考
-  暂无

